//The following serial code contains a loop and in each iteration some work is performed.


#include <stdio.h>

int main(int argc, char** argv) {
  int numbers = 10;

  for( int i=0; i<numbers; i++ ) {
    printf("I'm printing the number %d.\n", i);
  }
}

