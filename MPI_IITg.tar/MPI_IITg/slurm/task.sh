#!/bin/sh
#SBATCH -N 1                      		# specify number of nodes
#SBATCH --ntasks-per-node=20       		# specify number of cores per node
#SBATCH --time=01:00:00           		# specify maximum duration of run in hours:minutes:seconds format
#SBATCH --job-name=mpi_hello      		# specify job name
#SBATCH --error=job.%J.err       		# specify error file name
#SBATCH --output=job.%J.out        	# specify output file name
#SBATCH --partition=cpu             # specify type of resource such as  CPU/GPU/High memory etc.
### Load the default MPI module


ulimit -s unlimited 

module load spack/0.17

module load intel/2020
spack load openmpi /4dmpvc5
cd "/home/MPI_IITg/slurm"

### Run the mpi program with mpirun
  mpirun -np 2 ./prog1_output
  

