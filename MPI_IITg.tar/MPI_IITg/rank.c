//


#include <mpi.h>
#include <stdio.h>
int main(int argc, char** argv)
{
int rank;
// First call MPI_Init*
MPI_Init(&argc, &argv);
// Get my rank*
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
printf("My rank number is %d\n", rank);
// Call finalize at the end*
MPI_Finalize();
}
